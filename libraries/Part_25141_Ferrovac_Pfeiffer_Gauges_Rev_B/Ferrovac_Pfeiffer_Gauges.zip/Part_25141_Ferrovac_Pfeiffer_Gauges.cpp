#include "Arduino.h"
#include "Part_25141_Ferrovac_Pfeiffer_Gauges.h"


ReadGaugePressure::ReadGaugePressure(int pressure_type1, int pressure_medium1, int pressure_unit1)
{
	p_type = pressure_type1;
    p_medium = pressure_medium1;
    p_unit = pressure_unit1;
 }

double ReadGaugePressure::printPressure(int pressure_pin, double pressure_type, double pressure_medium, double pressure_unit){
	
	p_pin = pressure_pin;
if(p_pin == 61){
	p_pin = A3;
}
if(p_pin == 62){
	p_pin = A4;
}	
if(p_pin == 63){
	p_pin = A5;
}	
if(p_pin == 64){
	p_pin = A6;
}	
if(p_pin == 65){
	p_pin = A7;
}		
	p_type = pressure_type;
    p_medium = pressure_medium;
    p_unit = pressure_unit;
	
	double in_min;
    double in_max;
    double out_min;
    double out_max;
	
//Mit 16Bit Auflösung -> 1 DIGIT -> 0.0001 mbar

// Schritt 1: 0V - 3.3V ->  0 - 65536
// Schritt 2: Eingang nach Spannungsteiler -> Minimum - 0.847540 V (entspricht 2.2 V) bis Maximum - 3.27459 V (entspricht 8.5 V)
// Schritt 3: 0.847540 - 16831.6307394    3.27459 - 65031.372800
// Schritt 4: Skalierung des Analogwertes in Volt-Realer-Wert



 
//*****************************************PKR 261***********************************************************************************************************
  if(p_type == 0){//PKR 261
  
//---------------A3-------------------------
  if(p_pin == A3){
    _analog_value = analogRead(p_pin);
    in_min = 13771.35022;
    in_max = 65536;
    out_min = 1.8000000;
    out_max = 8.5659574467;

    Voltage_U = (_analog_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
   if(p_medium == 0){//Air
     
     if(p_unit == 0){//mbar
     
     
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.33));
	 

     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     }

   }

   else if(p_medium == 1){//Argon

     if(p_unit == 0){//mbar
     pressureValue = pow(10,((1.667 * Voltage_U) - 11.33));
     pressureValue = pressureValue * 0.8;
     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     pressureValue = pressureValue * 0.8;

     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     pressureValue = pressureValue * 0.8;

     }


   }
   
  }
//-----------------------------------------------------------------
//---------------A4-------------------------
if(p_pin == A4){
    _analog_value = analogRead(p_pin);
     in_min = 11679.68317;
     in_max = 55802.93069;
     out_min = 1.8000000;
     out_max = 8.6;

    Voltage_U = (_analog_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
   if(p_medium == 0){//Air
     
     if(p_unit == 0){//mbar
     
     
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.33));
	 

     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     }

   }

   else if(p_medium == 1){//Argon

     if(p_unit == 0){//mbar
     pressureValue = pow(10,((1.667 * Voltage_U) - 11.33));
     pressureValue = pressureValue * 0.8;
     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     pressureValue = pressureValue * 0.8;

     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     pressureValue = pressureValue * 0.8;

     }


   }
   
  }
//---------------------------------------------------------------------------------------
  
//---------------A5-------------------------
if(p_pin == A5){
    _analog_value = analogRead(p_pin);
     in_min = 11679.68317;
     in_max = 55802.93069;
     out_min = 1.8000000;
     out_max = 8.6;

    Voltage_U = (_analog_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
   if(p_medium == 0){//Air
     
     if(p_unit == 0){//mbar
     
     
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.33));
	 

     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     }

   }

   else if(p_medium == 1){//Argon

     if(p_unit == 0){//mbar
     pressureValue = pow(10,((1.667 * Voltage_U) - 11.33));
     pressureValue = pressureValue * 0.8;
     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     pressureValue = pressureValue * 0.8;

     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     pressureValue = pressureValue * 0.8;

     }


   }
   
  }
//--------------------------------------------------------------------------------------- 

//---------------A6-------------------------
if(p_pin == A6){
    _analog_value = analogRead(p_pin);
     in_min = 11679.68317;
     in_max = 55802.93069;
     out_min = 1.8000000;
     out_max = 8.6;

    Voltage_U = (_analog_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
   if(p_medium == 0){//Air
     
     if(p_unit == 0){//mbar
     
     
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.33));
	 

     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     }

   }

   else if(p_medium == 1){//Argon

     if(p_unit == 0){//mbar
     pressureValue = pow(10,((1.667 * Voltage_U) - 11.33));
     pressureValue = pressureValue * 0.8;
     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     pressureValue = pressureValue * 0.8;

     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     pressureValue = pressureValue * 0.8;

     }


   }
   
  }
//---------------------------------------------------------------------------------------

//---------------A7-------------------------
if(p_pin == A7){
    _analog_value = analogRead(p_pin);
     in_min = 11679.68317;
     in_max = 55802.93069;
     out_min = 1.8000000;
     out_max = 8.6;

    Voltage_U = (_analog_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
   if(p_medium == 0){//Air
     
     if(p_unit == 0){//mbar
     
     
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.33));
	 

     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     }

   }

   else if(p_medium == 1){//Argon

     if(p_unit == 0){//mbar
     pressureValue = pow(10,((1.667 * Voltage_U) - 11.33));
     pressureValue = pressureValue * 0.8;
     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     pressureValue = pressureValue * 0.8;

     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     pressureValue = pressureValue * 0.8;

     }


   }
   
  }
//---------------------------------------------------------------------------------------
  }
//***********************************************************************************************************************************************************

//*****************************************PKR 360***********************************************************************************************************
else if(p_type == 1){//PKR 360

//---------------A3-------------------------
  if(p_pin == A3){
	_analog_value = analogRead(p_pin);
    in_min = 15301.50025;
    in_max = 65536;
    out_min = 2.0000000;
    out_max = 8.5659574467;
	
    Voltage_U = (_analog_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;

   if(p_medium == 0){//N2

     if(p_unit == 0){//mbar
     
     
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.33));

     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     }




   }

   else if(p_medium == 1){//Argon


     if(p_unit == 0){//mbar
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.33));
     pressureValue = pressureValue * 0.8;
     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     pressureValue = pressureValue * 0.8;

     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     pressureValue = pressureValue * 0.8;

     }



   }
  }
//---------------------------------------------------------------------------------------

//---------------A4-------------------------
  if(p_pin == A4){
	_analog_value = analogRead(p_pin);
    in_min = 12977.42574;
    in_max = 55802.93069;
    out_min = 2.0000000;
    out_max = 8.6;
	
    Voltage_U = (_analog_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;

   if(p_medium == 0){//N2

     if(p_unit == 0){//mbar
     
     
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.33));

     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     }




   }

   else if(p_medium == 1){//Argon


     if(p_unit == 0){//mbar
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.33));
     pressureValue = pressureValue * 0.8;
     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     pressureValue = pressureValue * 0.8;

     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     pressureValue = pressureValue * 0.8;

     }



   }
  }
//---------------------------------------------------------------------------------------

//---------------A5-------------------------
  if(p_pin == A5){
	_analog_value = analogRead(p_pin);
    in_min = 12977.42574;
    in_max = 55802.93069;
    out_min = 2.0000000;
    out_max = 8.6;
	
    Voltage_U = (_analog_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;

   if(p_medium == 0){//N2

     if(p_unit == 0){//mbar
     
     
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.33));

     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     }




   }

   else if(p_medium == 1){//Argon


     if(p_unit == 0){//mbar
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.33));
     pressureValue = pressureValue * 0.8;
     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     pressureValue = pressureValue * 0.8;

     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     pressureValue = pressureValue * 0.8;

     }



   }
  }
//---------------------------------------------------------------------------------------

//---------------A6-------------------------
  if(p_pin == A6){
	_analog_value = analogRead(p_pin);
    in_min = 12977.42574;
    in_max = 55802.93069;
    out_min = 2.0000000;
    out_max = 8.6;
	
    Voltage_U = (_analog_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;

   if(p_medium == 0){//N2

     if(p_unit == 0){//mbar
     
     
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.33));

     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     }




   }

   else if(p_medium == 1){//Argon


     if(p_unit == 0){//mbar
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.33));
     pressureValue = pressureValue * 0.8;
     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     pressureValue = pressureValue * 0.8;

     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     pressureValue = pressureValue * 0.8;

     }



   }
  }
//---------------------------------------------------------------------------------------

//---------------A7-------------------------
  if(p_pin == A7){
	_analog_value = analogRead(p_pin);
    in_min = 12977.42574;
    in_max = 55802.93069;
    out_min = 2.0000000;
    out_max = 8.6;
	
    Voltage_U = (_analog_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;

   if(p_medium == 0){//N2

     if(p_unit == 0){//mbar
     
     
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.33));

     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     }




   }

   else if(p_medium == 1){//Argon


     if(p_unit == 0){//mbar
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.33));
     pressureValue = pressureValue * 0.8;
     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, ((1.667 * Voltage_U) - 11.46));
     pressureValue = pressureValue * 0.8;

     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, ((1.667 * Voltage_U) - 9.33));
     pressureValue = pressureValue * 0.8;

     }



   }
  }
//---------------------------------------------------------------------------------------
}

//***********************************************************************************************************************************************************

//*****************************************TPR 280***********************************************************************************************************

 else if(p_type == 2){//TPR 280
 
 //---------------A3-------------------------
  if(p_pin == A3){
	_analog_value = analogRead(p_pin);
    in_min = 16831.65027;
    in_max = 65031.37605;
    out_min = 2.2000000;
    out_max = 8.5000000;
	
    Voltage_U = (_analog_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;

   if(p_medium == 0){//N2

     if(p_unit == 0){//mbar
     pressureValue = pow(10, (Voltage_U - 5.5));
     
     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, (Voltage_U - 5.625));
     
     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, (Voltage_U - 3.5));
     
     }


   }

   else if(p_medium == 1){//Argon

     if(p_unit == 0){//mbar
     pressureValue = pow(10, (Voltage_U - 5.5));
     pressureValue = pressureValue * 1.7;

     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, (Voltage_U - 5.625));
     pressureValue = pressureValue * 1.7;

     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, (Voltage_U - 3.5));
     pressureValue = pressureValue * 1.7;

     }



   }

  }
//---------------------------------------------------------------------------------------

 //---------------A4-------------------------
  if(p_pin == A4){
	_analog_value = analogRead(p_pin);
    in_min = 14275.16832;
    in_max = 55154.05941;
    out_min = 2.2000000;
    out_max = 8.5000000;
	
    Voltage_U = (_analog_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;

   if(p_medium == 0){//N2

     if(p_unit == 0){//mbar
     pressureValue = pow(10, (Voltage_U - 5.5));
     
     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, (Voltage_U - 5.625));
     
     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, (Voltage_U - 3.5));
     
     }


   }

   else if(p_medium == 1){//Argon

     if(p_unit == 0){//mbar
     pressureValue = pow(10, (Voltage_U - 5.5));
     pressureValue = pressureValue * 1.7;

     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, (Voltage_U - 5.625));
     pressureValue = pressureValue * 1.7;

     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, (Voltage_U - 3.5));
     pressureValue = pressureValue * 1.7;

     }



   }

  }
//---------------------------------------------------------------------------------------

 //---------------A5-------------------------
  if(p_pin == A5){
	_analog_value = analogRead(p_pin);
    in_min = 14275.16832;
    in_max = 55154.05941;
    out_min = 2.2000000;
    out_max = 8.5000000;
	
    Voltage_U = (_analog_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;

   if(p_medium == 0){//N2

     if(p_unit == 0){//mbar
     pressureValue = pow(10, (Voltage_U - 5.5));
     
     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, (Voltage_U - 5.625));
     
     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, (Voltage_U - 3.5));
     
     }


   }

   else if(p_medium == 1){//Argon

     if(p_unit == 0){//mbar
     pressureValue = pow(10, (Voltage_U - 5.5));
     pressureValue = pressureValue * 1.7;

     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, (Voltage_U - 5.625));
     pressureValue = pressureValue * 1.7;

     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, (Voltage_U - 3.5));
     pressureValue = pressureValue * 1.7;

     }



   }

  }
//---------------------------------------------------------------------------------------

 //---------------A6-------------------------
  if(p_pin == A6){
	_analog_value = analogRead(p_pin);
    in_min = 14275.16832;
    in_max = 55154.05941;
    out_min = 2.2000000;
    out_max = 8.5000000;
	
    Voltage_U = (_analog_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;

   if(p_medium == 0){//N2

     if(p_unit == 0){//mbar
     pressureValue = pow(10, (Voltage_U - 5.5));
     
     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, (Voltage_U - 5.625));
     
     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, (Voltage_U - 3.5));
     
     }


   }

   else if(p_medium == 1){//Argon

     if(p_unit == 0){//mbar
     pressureValue = pow(10, (Voltage_U - 5.5));
     pressureValue = pressureValue * 1.7;

     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, (Voltage_U - 5.625));
     pressureValue = pressureValue * 1.7;

     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, (Voltage_U - 3.5));
     pressureValue = pressureValue * 1.7;

     }



   }

  }
//---------------------------------------------------------------------------------------

 //---------------A7-------------------------
  if(p_pin == A7){
	_analog_value = analogRead(p_pin);
    in_min = 14275.16832;
    in_max = 55154.05941;
    out_min = 2.2000000;
    out_max = 8.5000000;
	
    Voltage_U = (_analog_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;

   if(p_medium == 0){//N2

     if(p_unit == 0){//mbar
     pressureValue = pow(10, (Voltage_U - 5.5));
     
     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, (Voltage_U - 5.625));
     
     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, (Voltage_U - 3.5));
     
     }


   }

   else if(p_medium == 1){//Argon

     if(p_unit == 0){//mbar
     pressureValue = pow(10, (Voltage_U - 5.5));
     pressureValue = pressureValue * 1.7;

     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, (Voltage_U - 5.625));
     pressureValue = pressureValue * 1.7;

     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, (Voltage_U - 3.5));
     pressureValue = pressureValue * 1.7;

     }



   }

  }
//---------------------------------------------------------------------------------------

 }

//***********************************************************************************************************************************************************

//*****************************************PCR 280***********************************************************************************************************

 else if(p_type == 3){//PCR 280

 //---------------A3-------------------------
  if(p_pin == A3){
	_analog_value = analogRead(p_pin);
    in_min = 9180.90015;
    in_max = 65536;
    out_min = 1.2000000;
    out_max = 8.5659574467;

    Voltage_U = (_analog_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;

   if(p_medium == 0){//N2

     if(p_unit == 0){//mbar
     pressureValue = pow(10, (Voltage_U - 5.5));
     
     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, (Voltage_U - 5.625));
     
     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, (Voltage_U - 3.5));
     
     }


   }

   else if(p_medium == 1){//Argon

     if(p_unit == 0){//mbar
     pressureValue = pow(10, (Voltage_U - 5.5));
     pressureValue = pressureValue * 1.7;

     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, (Voltage_U - 5.625));
     pressureValue = pressureValue * 1.7;

     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, (Voltage_U - 3.5));
     pressureValue = pressureValue * 1.7;

     }



   }
  }
//---------------------------------------------------------------------------------------


//---------------A5-------------------------
  if(p_pin == A5){
	_analog_value = analogRead(p_pin);
    in_min = 7786.455445;
    in_max = 56322.02772;
    out_min = 1.2000000;
    out_max = 8.68;

    Voltage_U = (_analog_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;

   if(p_medium == 0){//N2

     if(p_unit == 0){//mbar
     pressureValue = pow(10, (Voltage_U - 5.5));
     
     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, (Voltage_U - 5.625));
     
     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, (Voltage_U - 3.5));
     
     }


   }

   else if(p_medium == 1){//Argon

     if(p_unit == 0){//mbar
     pressureValue = pow(10, (Voltage_U - 5.5));
     pressureValue = pressureValue * 1.7;

     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, (Voltage_U - 5.625));
     pressureValue = pressureValue * 1.7;

     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, (Voltage_U - 3.5));
     pressureValue = pressureValue * 1.7;

     }



   }
  }
//---------------------------------------------------------------------------------------

//---------------A6-------------------------
  if(p_pin == A6){
	_analog_value = analogRead(p_pin);
    in_min = 7786.455445;
    in_max = 56322.02772;
    out_min = 1.2000000;
    out_max = 8.68;

    Voltage_U = (_analog_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;

   if(p_medium == 0){//N2

     if(p_unit == 0){//mbar
     pressureValue = pow(10, (Voltage_U - 5.5));
     
     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, (Voltage_U - 5.625));
     
     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, (Voltage_U - 3.5));
     
     }


   }

   else if(p_medium == 1){//Argon

     if(p_unit == 0){//mbar
     pressureValue = pow(10, (Voltage_U - 5.5));
     pressureValue = pressureValue * 1.7;

     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, (Voltage_U - 5.625));
     pressureValue = pressureValue * 1.7;

     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, (Voltage_U - 3.5));
     pressureValue = pressureValue * 1.7;

     }



   }
  }
//---------------------------------------------------------------------------------------

//---------------A7-------------------------
  if(p_pin == A7){
	_analog_value = analogRead(p_pin);
    in_min = 7786.455445;
    in_max = 56322.02772;
    out_min = 1.2000000;
    out_max = 8.68;

    Voltage_U = (_analog_value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;

   if(p_medium == 0){//N2

     if(p_unit == 0){//mbar
     pressureValue = pow(10, (Voltage_U - 5.5));
     
     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, (Voltage_U - 5.625));
     
     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, (Voltage_U - 3.5));
     
     }


   }

   else if(p_medium == 1){//Argon

     if(p_unit == 0){//mbar
     pressureValue = pow(10, (Voltage_U - 5.5));
     pressureValue = pressureValue * 1.7;

     }

     else if(p_unit == 1){//Torr
     pressureValue = pow(10, (Voltage_U - 5.625));
     pressureValue = pressureValue * 1.7;

     }


     else if(p_unit == 2){//Pa
     pressureValue = pow(10, (Voltage_U - 3.5));
     pressureValue = pressureValue * 1.7;

     }



   }
  }
//---------------------------------------------------------------------------------------
 }  
  

     return pressureValue;
	
}
